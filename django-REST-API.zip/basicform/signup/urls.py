from django.urls import path, include
from . import views



urlpatterns = [
    path('',views.home, name='home'),
    path('signup/', views.signup, name='signup'),
    path('login/',views.login_request, name='login'),
    path('details/', views.details_required, name="details"),
    path('details/logout/', views.logout_request, name='logout'),
    path('api/', views.API_objects.as_view()),
    path('api/<int:pk>/', views.API_objects_details.as_view()),
]