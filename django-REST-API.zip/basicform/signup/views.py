from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .forms import SignUpForm,LoginForm
from django.contrib import messages
from django.contrib import auth
from .models import details
from django.core.exceptions import ValidationError
from rest_framework import generics
from .serilaizers import detailSerializers
# Create your views here.

def home(request):
    return render(request, 'registration/base.html')


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect(details_required)

    else:
        form = SignUpForm()
    return render(request, 'registration/signup.html', {'form': form})

def login_request(request):
    form = LoginForm()
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect(details_required)
        else:
            messages.error(request, f'Invalid Username and Password')
            
    else:
        form = LoginForm()
        
    return render(request, 'registration/login.html', {'form': form})


def logout_request(request):
    auth.logout(request)
    return redirect(home)
    

def details_required(request):
    if request.method == 'POST':
        if request.POST.get('name') and request.POST.get('number'):
            d = details()
            d.name = request.POST.get('name')
            d.number =  request.POST.get('number')
            d.save()

    context ={
            'content': details.objects.all()
        }
    return render(request, 'registration/det.html', context)


class API_objects(generics.CreateAPIView):
    queryset = details.objects.all()
    serializer_class = detailSerializers

class API_objects_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = details.objects.all()
    serializer_class = detailSerializers