from django.apps import AppConfig


class SignupConfig(AppConfig):
    name = 'signup'
